import Toybox.Graphics;
import Toybox.Lang;
import Toybox.System;
import Toybox.WatchUi;
import Toybox.Time;
import Toybox.Time.Gregorian;

class MinimalistFaceView extends WatchUi.WatchFace {

    private const COLOR_BG      = 0x000000;
    private const COLOR_TIME    = 0xFFFFFF;
    private const COLOR_DATE    = 0x888888;
    private const COLOR_DATA    = 0xCCCCCC;
    private const COLOR_LABEL   = 0x555555;
    private const COLOR_DIVIDER = 0x2A2A2A;
    private const COLOR_BAR_BG  = 0x222222;
    private const COLOR_BAR_FG  = 0x444444;

    private var myCustomFont = null;

    function initialize() {
        WatchFace.initialize();
    }

    // Load your 75pt Archivo font resource here
    function onLayout(dc as Dc) as Void {
        // Safe check: Ensure Rez.Fonts.BigFont matches your resources.xml precisely
        if (Rez has :Fonts && Rez.Fonts has :BigFont) {
            myCustomFont = WatchUi.loadResource(Rez.Fonts.BigFont);
        } else {
            // Fallback to a system font if the custom resource fails to load
            myCustomFont = Graphics.FONT_NUMBER_THAI_HOT;
        }
    }

    function onShow() as Void {}

    function onUpdate(dc as Dc) as Void {
        var w  = dc.getWidth();
        var h  = dc.getHeight();
        var cx = w / 2;

        // Background
        dc.setColor(COLOR_BG, COLOR_BG);
        dc.clear();

        var clockTime = System.getClockTime();
        var now       = Time.now();

        // ── Time ─────────────────────────────────────────────
        var is24Hour = System.getDeviceSettings().is24Hour;
        var hours = clockTime.hour;
        if (!is24Hour) {
            hours = hours % 12;
            hours = (hours == 0) ? 12 : hours;
        }

        var timeStr = hours.format("%02d") + ":" + clockTime.min.format("%02d");
        dc.setColor(COLOR_TIME, Graphics.COLOR_TRANSPARENT);
        
        // Render using the loaded font safely
        if (myCustomFont != null) {
            dc.drawText(cx, h * 32 / 100, myCustomFont, timeStr,
                Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);
        }

        // ── Thin divider ──────────────────────────────────────
        dc.setColor(COLOR_DIVIDER, Graphics.COLOR_TRANSPARENT);
        dc.drawLine(cx - 55, h * 52 / 100, cx + 55, h * 52 / 100);

        // ── Date ──────────────────────────────────────────────
        var greg = Gregorian.info(now, Time.FORMAT_MEDIUM);
        
        // Safeguard to prevent method errors on string objects in strict environments
        var dayOfWeekStr = (greg.day_of_week instanceof Lang.String) ? greg.day_of_week.toUpper() : greg.day_of_week;
        var monthStr = (greg.month instanceof Lang.String) ? greg.month.toUpper() : greg.month;

        var dateStr = Lang.format("$1$ $2$ $3$", [
            dayOfWeekStr, 
            greg.day.format("%02d"), 
            monthStr
        ]);

        dc.setColor(COLOR_DATE, Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, h * 59 / 100, Graphics.FONT_TINY, dateStr,
            Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);

        // ── Battery ───────────────────────────────────────────
        var sysStats = System.getSystemStats();
        var batLevel = sysStats.battery.toNumber();  
        var batStr   = batLevel.format("%d") + "%";

        dc.setColor(COLOR_LABEL, Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, h * 71 / 100, Graphics.FONT_XTINY, "BATTERY",
            Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);

        dc.setColor(COLOR_DATA, Graphics.COLOR_TRANSPARENT);
        dc.drawText(cx, h * 79 / 100, Graphics.FONT_MEDIUM, batStr,
            Graphics.TEXT_JUSTIFY_CENTER | Graphics.TEXT_JUSTIFY_VCENTER);

        // ── Battery bar ───────────────────────────────────────
        var barW    = (w * 55 / 100).toNumber();
        var barLeft = ((w - barW) / 2).toNumber();
        var barY    = (h * 87 / 100).toNumber();
        var fillW   = (barW * batLevel / 100).toNumber();

        dc.setColor(COLOR_BAR_BG, Graphics.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(barLeft, barY, barW, 2, 1);

        dc.setColor(COLOR_BAR_FG, Graphics.COLOR_TRANSPARENT);
        dc.fillRoundedRectangle(barLeft, barY, fillW, 2, 1);
    }

    function onHide() as Void {}
    function onExitSleep() as Void {}
    function onEnterSleep() as Void {}
}